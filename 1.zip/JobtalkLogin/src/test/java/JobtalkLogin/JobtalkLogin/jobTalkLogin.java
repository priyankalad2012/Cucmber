package JobtalkLogin.JobtalkLogin;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.*;

public class jobTalkLogin  {

	public String baseUrl = "http://localhost:5173/login";
	public WebDriver driver;

	@BeforeTest

	public void SetUp() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));

	}

	@Test(priority = 1)
	public void testLogin() {
		driver.findElement(By.id("email")).sendKeys("akshayp@aptask.com");
		driver.findElement(By.id("password")).sendKeys("5AuhxFV61eVGw7GW");

		driver.findElement(By.xpath("//form[@class='space-y-6']/div/button")).submit();
	}

	@Test(priority = 2)
	public void testCampiagn() {

		driver.findElement(By.xpath("//*[@id='root']/div/nav/div/div/div[3]/div[2]/div[1]/div/div[2]/a")).click();
	
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.toString();
		}
		driver.findElement(By.xpath(
				"//*[@id='root']/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]"))
				.click();

		driver.findElement(By.name("jobDivaId")).sendKeys("25-09155");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[1]/div[1]/div[1]/div[2]/button"))
				.click();

		try {
			Thread.sleep(50000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[2]"));
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

// data fetch from Jobdiva (Start)

		driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[1]"))
				.click();
		driver.findElement(By.name("fetchContacts")).sendKeys("5");
////		driver.findElement(By.xpath(
//				"//*[@id='root']/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div[2]/div/div[2]/div/button"))
//				.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		driver.findElement(By.xpath("//*[@id='headlessui-dialog-panel-:rgn:']/div/div[2]/div/div[2]/div[2]/div/button[1]")).click();
//		try {
//			Thread.sleep(50000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		driver.findElement(By.xpath("//*[@id='headlessui-dialog-panel-:rgn:']/div/div[2]/div/div[2]/div[2]/div/button[2]")).click();

// data fetch from Jobdiva (End)

//	Upload CSV (Start)

//		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[2]")).click();
//		WebElement ContactUpload = driver.findElement(By.name("contacts"));
//		ContactUpload.sendKeys("C:\\Users\\Admin\\Downloads\\JobTalk_template (4).csv");

//	Upload CSV (End)

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		WebElement Questions = driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[4]/div[1]/div[1]/div[2]/div[2]/div/div[2]/select"));

		Select Question = new Select(Questions);
		Question.selectByVisibleText("Default");

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[2]/div/div/button")).click();

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[2]/div/div/button[2]")).click();
	}

//	@Test(priority =4)
//	public void testScheduleCampiagn()
//	{
//		driver.findElement(By.xpath("//*[@id=\\\"root\\\"]/div/div/main/div/div/div/form/div[2]/div/div/button")).click();
//	}

	@Test(priority = 3)
	public void testLogout() {
		try {
			Thread.sleep(50000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver.findElement(By.xpath("//button[@class='relative']/div")).click();

		driver.findElement(By.xpath("//div[@role='menu']/a[10]")).click();
	}

	@AfterSuite
	public void Teardown() {

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver.close();
		driver.quit();
	}

}
