package Com;


//import org.openqa.selenium.WebDriver;

//import PageObject.LoginPage;
import PageObject.LoginPageFactory;
import Util.Driverconnection;


public class myTest extends Driverconnection {
	
	public void login()
	{
		 driver = connect();
		//LoginPage login  = new LoginPage(driver);
		 
		 	
		LoginPageFactory login = new LoginPageFactory(driver);
		
		
		
		login.enterEmail("test@gmial.com");
		login.enterPass("test");
		login.clickLogin();
		
	}
}


