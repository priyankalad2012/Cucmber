package Com;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyDemo {
	
public static void main(String[] args) {
		
		
		try {
			FileInputStream fis = new FileInputStream("D:\\Priyanka\\AutomationTool\\eclipse\\1\\com.test\\src\\test\\java\\resources\\data.properties");
			Properties prop  = new Properties();
			
			prop.load(fis);
			
			String name =  prop.getProperty("name");
			
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
