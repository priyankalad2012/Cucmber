package com;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class ScheduleCampiagn {
WebDriver driver;
	
	@Test
	public void testCampiagn() {

		driver.findElement(By.xpath("//*[@id='root']/div/nav/div/div/div[3]/div[2]/div[1]/div/div[2]/a")).click();
	
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.toString();
		}
		driver.findElement(By.xpath(
				"//*[@id='root']/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]"))
				.click();

		driver.findElement(By.name("jobDivaId")).sendKeys("25-09155");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[1]/div[1]/div[1]/div[2]/button"))
				.click();

		try {
			Thread.sleep(50000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[2]"));
		jse.executeScript("arguments[0].scrollIntoView(true);", element);

// data fetch from Jobdiva (Start)

		driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[1]"))
				.click();
		driver.findElement(By.name("fetchContacts")).sendKeys("5");
////		driver.findElement(By.xpath(
//				"//*[@id='root']/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div[2]/div/div[2]/div/button"))
//				.click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		driver.findElement(By.xpath("//*[@id='headlessui-dialog-panel-:rgn:']/div/div[2]/div/div[2]/div[2]/div/button[1]")).click();
//		try {
//			Thread.sleep(50000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		driver.findElement(By.xpath("//*[@id='headlessui-dialog-panel-:rgn:']/div/div[2]/div/div[2]/div[2]/div/button[2]")).click();

// data fetch from Jobdiva (End)

//	Upload CSV (Start)

//		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[3]/div/div/div/div[2]/div[2]")).click();
//		WebElement ContactUpload = driver.findElement(By.name("contacts"));
//		ContactUpload.sendKeys("C:\\Users\\Admin\\Downloads\\JobTalk_template (4).csv");

//	Upload CSV (End)

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		WebElement Questions = driver.findElement(By.xpath(
				"//*[@id=\"root\"]/div/div/main/div/div/div/form/div[1]/div/div[2]/div/div[4]/div[1]/div[1]/div[2]/div[2]/div/div[2]/select"));

		Select Question = new Select(Questions);
		Question.selectByVisibleText("Default");

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[2]/div/div/button")).click();
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/main/div/div/div/form/div[2]/div/div/button[1]")).click();
		List<WebElement> dates= driver.findElements(By.xpath("//*[@id=\"headlessui-dialog-panel-:r1al:\"]/div/div[2]/div/div/div[2]/div[2]/div[2]/div/div/div[2]/div/div[5]/button[6]"));
		
		for (WebElement date : dates) {
			
			if(date.getText().equals("28"))
			{
				date.click();
				break;
			}
		}
	}

}
