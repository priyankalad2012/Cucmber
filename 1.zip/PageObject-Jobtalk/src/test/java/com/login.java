package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import util.commonConnection;

public class login {
	
	WebDriver driver;
	@BeforeClass
	private void setup() {

		driver=commonConnection.connect("http://localhost:5173/login");
	
	}
	@Test
	public void testLogin()
	{
		//driver=commonConnection.connect("https://www.demo.guru99.com/V4/");
		
		WebElement userId= driver.findElement(By.id("email"));
		userId.clear();
		userId.sendKeys("akshayp@aptask.com");
		WebElement password=driver.findElement(By.id("password"));
		password.clear();
		password.sendKeys("5AuhxFV61eVGw7GW");
		
		driver.findElement(By.xpath("//form[@class='space-y-6']/div/button")).click();
		
	}

}
