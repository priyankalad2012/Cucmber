package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.testng.annotations.Test;

import util.commonConnection;



public class logOut {
	
	WebDriver driver;
	
	@Test
	public void testLogout() {
		
		driver=commonConnection.connect("http://localhost:5173/dashboard");
		
		

		driver.findElement(By.xpath("//button[@class='relative']/div")).click();

		driver.findElement(By.xpath("//div[@role='menu']/a[10]")).click();
	}

}
